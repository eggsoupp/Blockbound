"""Build three solid, editable MagicaVoxel props and render exported geometry.

Python 3 + numpy + Pillow. Run from any directory. +Z up, Y thickness.
"""
from pathlib import Path
import json
import math
import zipfile
import numpy as np
from PIL import Image, ImageDraw
import voxel_utils as io

ROOT = Path(__file__).resolve().parents[1]
# Slots 1-16 preserve the project's existing wood/linen palette.
PALETTE = [
    ('Wood deep shadow', '#51351e'), ('Wood shadow', '#664322'),
    ('Wood dark edge', '#79522b'), ('Wood edge', '#896035'),
    ('Wood brown', '#997243'), ('Wood ochre', '#aa8250'),
    ('Wood warm', '#b7925d'), ('Wood tan', '#c3a36e'),
    ('Wood face', '#cdb480'), ('Wood light', '#d8bf8b'),
    ('Wood highlight', '#e1cc9b'), ('Linen shadow', '#8e8879'),
    ('Linen shade', '#a59e8d'), ('Linen base', '#bcb4a2'),
    ('Linen light', '#cec6b4'), ('Linen highlight', '#dfd6c2'),
    ('Steel deepest', '#363440'), ('Steel shadow', '#55535f'),
    ('Steel dark', '#72717b'), ('Steel body', '#94959a'),
    ('Steel light', '#b2b6b6'), ('Steel edge', '#cdd2ce'),
    ('Steel glint', '#e5e7d6'), ('Steel warm reflection', '#bcbda3'),
    ('Leather deep', '#4b2b22'), ('Leather shade', '#70412c'),
    ('Leather body', '#945333'), ('Leather light', '#b56c40'),
]
io.RGB = np.array([tuple(bytes.fromhex(h[1:])) for _, h in PALETTE], np.uint8)


class Sculpt:
    def __init__(self):
        self.v = {}

    def put(self, x, y, z, c):
        self.v[int(x), int(y), int(z)] = c

    def column(self, x, z, depth, c, side=None):
        for y in range(-depth, depth + 1):
            self.put(x, y, z, c if abs(y) == depth else (side or c))

    def shaft(self, z0, z1, width=2, depth=2):
        for z in range(z0, z1 + 1):
            for x in range(-width, width + 1):
                d = depth - int(abs(x) == width and depth > 1)
                # Continuous warm wood faces, darker chamfers, sparse grain.
                c = 6 if x == -1 else 5 if x == 0 else 4 if x == 1 else 3
                if x == 0 and z % 19 in (6, 7, 8):
                    c = 4
                self.column(x, z, d, c, 3)

    def ferrule(self, z0, z1, width=3, depth=3):
        for z in range(z0, z1+1):
            for x in range(-width, width+1):
                d = depth - int(abs(x) == width)
                c = 21 if x < 0 else 20 if x < width else 18
                if z in (z0, z1):
                    c = 22 if z == z1 else 19
                self.column(x, z, d, c, 19)

    def array(self):
        lo = np.min(list(self.v), axis=0)
        hi = np.max(list(self.v), axis=0)
        a = np.zeros(tuple(hi-lo+1), np.uint8)
        for p, c in self.v.items():
            a[tuple(np.array(p)-lo)] = c
        return a, (-lo).tolist()


def sword():
    s = Sculpt()
    # Octagonal wheel pommel, with an X of cut facets on both faces.
    for z in range(0, 9):
        dz = abs(z-4)
        w = 4 if dz <= 2 else 3 if dz == 3 else 2
        for x in range(-w, w+1):
            d = 3 if abs(x) < w and dz < 4 else 2
            c = 20 if x <= 0 else 21
            if abs(x) == dz:
                c = 18
            if z >= 7:
                c = 21
            s.column(x, z, d, c, 19)
    # Wrapped russet grip. Bands stand proud of the chamfered core.
    for z in range(9, 29):
        for x in range(-2, 3):
            s.column(x, z, 2 if abs(x) < 2 else 1,
                     28 if x == 1 else 27 if x >= 0 else 26, 25)
        if z in (9, 14, 19, 24, 28):
            for x in range(-2, 3):
                s.column(x, z, 3 if abs(x) < 2 else 2, 26, 25)
    # Slim swept quillons curve up toward the blade.
    for x in range(-18, 19):
        u = abs(x)
        bottom = 29 + max(0, (u-8)//2)
        h = 3 if u < 10 else 2
        if u <= 4:
            h += 2-int(u > 2)
        for z in range(bottom, bottom+h):
            d = 3 if u < 4 else 2 if u < 16 else 1
            c = 22 if z == bottom+h-1 else 20 if z > bottom else 19
            s.column(x, z, d, c, 19)
    # Long, straight blade with diamond bevels and a real recessed fuller.
    for z in range(33, 110):
        w = 4 if z <= 105 else 3 if z <= 107 else 2 if z == 108 else 1
        for x in range(-w, w+1):
            edge = w-abs(x)
            d = min(2, edge)
            fuller = x == 0 and 36 <= z <= 106
            if fuller:
                d = 1
            c = 22 if edge == 0 else 21
            if x == -1 and not fuller:
                c = 23
            if fuller:
                c = 19
            if edge == 1 and x > 0:
                c = 20
            s.column(x, z, d, c, 20)
    return s.array()


def pickaxe():
    s = Sculpt()
    s.shaft(2, 64)
    s.ferrule(0, 5, 2, 2)
    # Lower dark leather binding adjoining the end cap.
    for z in (6, 7):
        for x in range(-2, 3):
            s.column(x, z, 2 if abs(x) < 2 else 1, 26, 25)
    s.ferrule(47, 55, 3, 3)
    # Double tapered arcing steel head: points bend down at both ends.
    for x in range(-27, 28):
        u = abs(x)
        center = 58 - int(0.012*u*u + 0.00024*u*u*u)
        h = 3 if u < 9 else 2 if u < 19 else 1 if u < 27 else 0
        d = 3 if u < 7 else 2 if u < 19 else 1 if u < 26 else 0
        for z in range(center-h, center+h+1):
            surface_d = max(0, d-int(abs(z-center) == h and h > 1))
            c = 22 if z == center+h else 21 if z >= center else 19
            if z == center-h:
                c = 18 if u < 23 else 21
            if u >= 25:
                c = 23
            s.column(x, z, surface_d, c, 19)
    # Steel socket and raised cap are visible above the intersection.
    s.ferrule(54, 64, 3, 3)
    s.ferrule(65, 66, 2, 2)
    for sign in (-1, 1):
        for x in (-1, 0, 1):
            for z in (57, 58, 59):
                s.put(x, sign*4, z, 22 if x <= 0 and z >= 58 else 19)
    return s.array()


def axe():
    s = Sculpt()
    s.shaft(1, 56)
    # Slightly widened, rounded wooden butt.
    for z in range(0, 7):
        w = 2 if z in (0, 6) else 3
        for x in range(-w, w+1):
            s.column(x, z, 2 if abs(x) < w else 1,
                     6 if x < 0 else 5 if x < w else 3, 3)
    # A compact squared poll behind the haft.
    for x in range(-6, -1):
        for z in range(50, 60):
            d = 2 if x == -6 or z in (50, 59) else 3
            s.column(x, z, d, 21 if z >= 57 else 20 if x > -6 else 19, 19)
    # Broad asymmetric axe bit. Concave beard, convex sweeping cutting edge.
    # Each column gives its lower/upper outline. Thickness tapers toward edge.
    profile = {
        -1:(49,60), 0:(49,61), 1:(49,61), 2:(49,61),
        3:(49,61), 4:(50,61), 5:(51,62), 6:(51,62),
        7:(50,62), 8:(49,63), 9:(47,63), 10:(45,63),
        11:(43,64), 12:(42,64), 13:(41,64), 14:(40,65),
        15:(40,65), 16:(40,65), 17:(41,65), 18:(42,65),
        19:(44,65), 20:(46,64), 21:(48,64), 22:(50,63),
        23:(53,62), 24:(56,61), 25:(58,60),
    }
    for x, (low, high) in profile.items():
        for z in range(low, high+1):
            # The curved edge is the rightmost occupied voxel on each row.
            right = max(xx for xx,(l,h) in profile.items() if l <= z <= h)
            edge = right-x
            border = min(z-low, high-z)
            d = min(3, max(0, edge//2))
            if x < 6:
                d = 3
            if border == 0:
                d = max(0, d-1)
            c = 23 if edge == 0 else 22 if edge <= 2 else 21 if edge <= 4 else 20
            if edge > 4 and (z == high or z == high-1):
                c = 22
            if edge > 4 and z <= low+1:
                c = 18
            if edge > 5 and (x+z)//5 % 4 == 0:
                c = max(19, c-1)
            s.column(x, z, d, c, 19)
    # Thick eye surrounding the handle, plus a small peened pin on either side.
    s.ferrule(50, 60, 3, 3)
    for sign in (-1, 1):
        for x in (-1, 0, 1):
            for z in (54, 55, 56):
                s.put(x, sign*4, z, 22 if x <= 0 and z >= 55 else 19)
    return s.array()


def palette_files():
    data = {'name':'Blockbound - Wood, Linen, Steel and Leather',
            'indexing':'0 is empty. RGBA entry 0 maps to voxel color index 1.',
            'compatibility':'Indices 1-16 preserve the existing wooden sword palette.',
            'colors':[{'index':i+1,'name':name,'hex':h} for i,(name,h) in enumerate(PALETTE)]}
    (ROOT/'shared_palette.json').write_text(json.dumps(data, indent=2)+'\n')
    gpl = ['GIMP Palette', 'Name: Blockbound shared tool palette', 'Columns: 7', '#']
    for i, ((name,h), rgb) in enumerate(zip(PALETTE, io.RGB)):
        gpl.append(f'{rgb[0]:3} {rgb[1]:3} {rgb[2]:3}\t{i+1:02} {name}')
    (ROOT/'shared_palette.gpl').write_text('\n'.join(gpl)+'\n')
    im = Image.new('RGB',(1120,240),'#1b2028')
    d = ImageDraw.Draw(im)
    for i,(_,h) in enumerate(PALETTE):
        x,y = (i%14)*80, (i//14)*120
        d.rectangle((x+6,y+6,x+73,y+80),fill=h)
        d.text((x+12,y+88),f'{i+1:02d}  {h[1:]}',font=io.font(11),fill='#d3d5d9')
    im.save(ROOT/'shared_palette.png')


def previews(models):
    pre = ROOT/'previews'
    pre.mkdir(exist_ok=True)
    overview = Image.new('RGB',(1800,1080),'#1b2028')
    d = ImageDraw.Draw(overview)
    d.text((64,34),'BLOCKBOUND / STEEL TOOLSET',font=io.font(36,True),fill='#e5e7df')
    d.text((66,86),'Sword, pickaxe and axe  /  one shared indexed palette',font=io.font(20),fill='#a1aab7')
    for i,(name,a,report) in enumerate(models):
        title = name.replace('_',' ').upper()
        scale = min(9.8, 760/a.shape[2], 510/a.shape[0])
        hero = io.render(a,(560,800),az=-74,el=10,scale=scale)
        hero.save(pre/f'{name}_transparent.png')
        overview.paste(hero,(20+i*600,140),hero)
        d.text((65+i*600,951),title,font=io.font(25,True),fill='#e5e7df')
        d.text((65+i*600,995),' x '.join(map(str,a.shape))+' voxels',font=io.font(19),fill='#a1aab7')
        sheet = Image.new('RGB',(1600,1080),'#1b2028')
        sd = ImageDraw.Draw(sheet)
        sd.text((52,28),title,font=io.font(32,True),fill='#e5e7df')
        views = [('FRONT',-90,0),('THREE QUARTER',-55,15),('BACK',90,0),('SIDE',0,0)]
        for j,(label,az,el) in enumerate(views):
            scale2 = min(8.8,810/a.shape[2],350/a.shape[0])
            im = io.render(a,(380,850),az=az,el=el,scale=scale2)
            sheet.paste(im,(10+j*400,125),im)
            sd.text((36+j*400,98),label,font=io.font(18,True),fill='#a1aab7')
        sd.text((52,1014),f'{report["voxels"]:,} solid voxels  /  +Z up  /  Y depth  /  previews rendered from exported VOX',font=io.font(18),fill='#a1aab7')
        sheet.save(pre/f'{name}_views.png')
    overview.save(pre/'steel_toolset.png')


def main():
    ROOT.mkdir(exist_ok=True)
    models=[]
    for name, builder in [('steel_sword',sword),('steel_pickaxe',pickaxe),('steel_axe',axe)]:
        a, origin = builder()
        path = ROOT/f'{name}.vox'
        io.export_vox(path,a)
        restored, report = io.validate(path,a)
        report['design_origin_xyz'] = origin
        report['grip_anchor_xyz'] = [origin[0],origin[1],origin[2]+(18 if name=='steel_sword' else 23)]
        models.append((name,restored,report))
    assert len({r['rgba_sha256'] for _,_,r in models}) == 1
    palette_files()
    previews(models)
    (ROOT/'validation.json').write_text(json.dumps({'identical_palettes':True,'models':[r for _,_,r in models]},indent=2)+'\n')
    (ROOT/'README.md').write_text('''# Blockbound steel toolset

Three solid 3D voxel models based on the supplied sword, pickaxe and axe references.

- **steel_sword.vox**: long beveled blade, recessed fuller, swept crossguard, leather wrap and faceted wheel pommel.
- **steel_pickaxe.vox**: curved double-ended steel head, central socket, wooden shaft and metal end cap.
- **steel_axe.vox**: broad single cutting bit with a curved bevel and hooked beard, compact poll and wooden handle.

All files are MagicaVoxel VOX version 150 with one editable voxel volume per file. The models are upright: +Z toward the head/tip, X across the head, Y thickness. The axe cutting edge faces +X. Import scale is left to the game. The diagonal poses in the references are normalized to upright local coordinates.

## Shared palette

All three VOX files embed an identical complete 256-entry RGBA chunk. Slots 1-28 are named colors; slot 0 is empty. The 16 existing wood/linen colors remain in their original slots, with steel and leather appended. `shared_palette.json`, `.gpl` and `.png` are included. Each model uses the relevant subset. The earlier wooden sword files are untouched.

## Previews and validation

`previews/steel_toolset.png` shows the set. Each model also has a transparent preview and front, angled, rear and side views. All previews are rendered from the geometry decoded from the exported VOX files; directional light slightly shades the palette colors in previews.

`validation.json` records dimensions, voxel counts, palette hashes and grip anchors in voxel coordinates. Every file passes binary round-trip, chunk size, bounds, unique coordinate, palette index and six-neighbor connectivity checks. Each is one connected solid with no background, watermark, ground plane or stand.

To rebuild: install Python 3, NumPy and Pillow, then run `python source/build_toolset.py`. The source is self-contained within this folder.
''',encoding='utf-8')
    with zipfile.ZipFile(ROOT/'steel_toolset.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and p.suffix != '.zip' and '__pycache__' not in p.parts:
                archive.write(p,p.relative_to(ROOT))
    print(json.dumps([r for _,_,r in models],indent=2))


if __name__ == '__main__':
    main()
