# Blockbound steel toolset

Three solid 3D voxel models based on the supplied sword, pickaxe and axe references.

- **steel_sword.vox**: long beveled blade, recessed fuller, swept crossguard, leather wrap and faceted wheel pommel.
- **steel_pickaxe.vox**: curved double-ended steel head, central socket, wooden shaft and metal end cap.
- **steel_axe.vox**: broad single cutting bit with a curved bevel and hooked beard, compact poll and wooden handle.

All files are MagicaVoxel VOX version 150 with one editable voxel volume per file. The models are upright: +Z toward the head/tip, X across the head, Y thickness. The axe cutting edge faces +X. Import scale is left to the game. The diagonal poses in the references are normalized to upright local coordinates.

## Shared palette

All three VOX files embed an identical complete 256-entry RGBA chunk. Slots 1-28 are named colors; slot 0 is empty. The 16 existing wood/linen colors remain in their original slots, with steel and leather appended. `shared_palette.json`, `.gpl` and `.png` are included. Each model uses the relevant subset. The earlier wooden sword files are untouched.

## Previews and validation

`previews/steel_toolset.png` shows the set. Each model also has a transparent preview and front, angled, rear and side views. All previews are rendered from the geometry decoded from the exported VOX files; directional light slightly shades the palette colors in previews.

`validation.json` records dimensions, voxel counts, palette hashes and grip anchors in voxel coordinates. Every file passes binary round-trip, chunk size, bounds, unique coordinate, palette index and six-neighbor connectivity checks. Each is one connected solid with no background, watermark, ground plane or stand.

To rebuild: install Python 3, NumPy and Pillow, then run `python source/build_toolset.py`. The source is self-contained within this folder.
