# Blockbound - Homeward themes

Current exports: melody, adventure1, adventure2, adventure3, allseeingeye, each as WAV and MIDI.
Exploration tracks remain revision 2. Allseeingeye is revision 5, an electronic boss arrangement.

Allseeingeye: 69.7 seconds, with the drop at 10.435 seconds and 186 BPM thereafter.
The piano intro has the same notes and timing, reduced 4.5 dB from revision 4.
The section after the drop is raised 2 dB RMS relative to revision 4, with gentle peak control.
The guitars are replaced by a wide custom electronic lead, a lower synth layer, pulsing chords
and a flowing synth figure. Piano countermelody, minor harmony, bass and chopped breaks remain.
There are no metallic/glass effects. Power comes from layered music and dynamic contrast.

Broad inspiration: Universal Collapse by DM DOKURO, https://dmdokuro.bandcamp.com/track/universal-collapse
The original Homeward melody and newly written countermelody are retained; no reference recording or transcription is used.

Audio: 44.1 kHz, 16-bit stereo WAV. MIDI has separate named parts and tempo/section markers.
The custom synth instruments use General MIDI proxies; synthesis and drum edits are baked into WAV.
Use compose_allseeingeye_v5.py to rebuild this boss. Earlier exports are in previous_v1 through previous_v4.
The current ZIP includes all current audio and MIDI files. validation.json records the volume and export checks.
Sample source: existing GeneralUser GS by S. Christian Collins; license in .music-tools/GeneralUser-LICENSE.txt.
